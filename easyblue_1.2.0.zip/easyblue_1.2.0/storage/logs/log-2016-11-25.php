<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-25 22:00:02 --> Severity: Error --> Call to undefined method User_Model::get_user_email() /volume1/web/wordpress/easy/application/controllers/cli/Waitinglist.php 50
